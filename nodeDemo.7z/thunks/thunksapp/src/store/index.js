import { configureStore, createSlice } from "@reduxjs/toolkit";

const counterSlicer = createSlice({
  name: "counter",
  initialState: { counter: 0 },
  reducers: {
    increment(state, action) {
      state.counter += 1;
    },
    decrement(state, action) {
      state.counter -= 1;
    },
    addby(state, action) {
      state.counter += action.payload;
    },
  },
  
});

export const actions = counterSlicer.actions;
const store = configureStore({
  reducer: counterSlicer.reducer,
});
export default store;

// import { createStore } from "redux";

// const reducer = (state = { counter: 0 }, action) => {
//   /**
//    * !! LIMITATIONS
//    * 1. It should be synchronous function (nothing should be as async)
//    * 2. It should not be mutating the original state, use the copy of state
//    */

//   if (action.type === "INC") {
//     return { counter: state.counter + 1 };
//   }
//   if (action.type === "DEC") {
//     return { counter: state.counter - 1 };
//   }
//   if (action.type === "ADDBY") {
//     return { counter: state.counter + 10 };
//   }
//   return state;
// };
// const store = createStore(reducer);
// export default store;
