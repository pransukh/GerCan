import { configureStore } from "@reduxjs/toolkit";
import auth from "./store/slicer/auth";
import cart from "./store/slicer/cart";

const store = configureStore({
    reducer: {
        authentication: auth.reducer,
        cart : cart.reducer,
    }
});
export default store; // is being used in ../src/index.js <provider> to get access in whole application.