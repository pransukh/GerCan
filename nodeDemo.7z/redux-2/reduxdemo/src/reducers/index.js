import performAction from "./add-sub";
import {combineReducers} from "redux";

const rootReducer = combineReducers({
performAction
});

export default rootReducer;