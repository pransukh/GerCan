import React, { Component } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {inc,dec} from "./actions/index"

const App = () =>{
  const mystate = useSelector((state) => state.performAction);
  const dispatch = useDispatch();
  return (<div>
      <button type="button" id="minus" onClick={() => dispatch(dec(1))}> - </button>
      <input type="text" id="show" value ={mystate}/>       
      <button type="button" id="add" onClick={() => dispatch(inc(1))}> + </button>
      </div>
  );
}

export default App;