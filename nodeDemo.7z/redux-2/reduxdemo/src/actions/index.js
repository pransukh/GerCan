const inc = () => {
    return {
        type: "ADD_ASYNC"
    }
}
const dec = () => {
    return {
        type: "SUB"
    }
}
export {
    inc, dec
}