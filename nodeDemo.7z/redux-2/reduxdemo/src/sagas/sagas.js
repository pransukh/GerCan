import {takeEvery, put} from 'redux-saga/effects'

function* upAsync(){
    yield put({type: 'ADD_ASYNC', value: 1});
}





export function* watchUp(){
    yield takeEvery('ADD', upAsync);
}