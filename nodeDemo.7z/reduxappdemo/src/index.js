import store from "./store";
import {bugAdded, bugResolved} from './actions';
import React from "react";
import reactDom from "react-dom";
import App from "./App";
import "bootstrap/dist/css/bootstrap.css";

reactDom.render(<App/>,document.getElementById('root'));

store.dispatch(bugAdded("BUG ADDED 1"));
store.dispatch(bugResolved(1));



