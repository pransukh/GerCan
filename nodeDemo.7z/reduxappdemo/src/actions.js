import * as actions from './actionsTypes';

export const bugAdded = desc => ({
    type: actions.BUG_ADDED,
    payload: {
        description: desc
    }
});

export const bugResolved = id => ({
 type: actions.BUG_RESOLVED,
 payload: {
     id
 }
});
// export function bugAdded(des){
//     return {
//         type: actions.BUG_ADDED,
//         payload: {
//             description: des
//         }
//     }
// }