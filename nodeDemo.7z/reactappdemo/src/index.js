import React from "react";
import reactDom from "react-dom";
import Counters from "./components/counters";
import "bootstrap/dist/css/bootstrap.css";

reactDom.render(<Counters/>,document.getElementById('root'));
